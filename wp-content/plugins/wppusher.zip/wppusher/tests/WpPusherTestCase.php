<?php

class WpPusherTestCase extends PHPUnit_Framework_TestCase
{
}
